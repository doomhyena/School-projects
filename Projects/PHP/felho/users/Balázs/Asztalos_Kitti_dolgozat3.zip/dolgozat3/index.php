<?php

	require "config.php";
	
	session_start();
	
	if(!isset($_SESSION('post-btn'))){
		
		header("Location: reg.php");
		
	}


?>

<form method type="post">

	<input type="text" name="uzenet" placeholder="Írj valamit...">

	<input type="submit" name="post-btn">

</form>
