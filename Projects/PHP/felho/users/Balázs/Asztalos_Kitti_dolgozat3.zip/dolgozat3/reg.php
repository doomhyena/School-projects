<?php

	require "config.php";
	
	session_start();
	
	if(isset($_SESSION('reg-btn'))){
		
		$user = $_SESSION['id'];
		
		header("Location: login.php");
		
	}
	



?>

<form method type="post">

	<input type="text" name="username" placeholder="Felhasználónév">
	
	<br><br>
	
	<input type="text" name="password" placeholder="Jelszó">
	
	<br><br>
	
	<input type="submit" name="reg-btn" value="Regisztráció">

</form>

<a>Már regisztráltál? Jelentkezz be itt!</a><a href="login.php"></a>