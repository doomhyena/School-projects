<?php

	$conn = new mysqli("localhost", "root", "", "asztaloskitti_harmadik");
	
	if($conn->connect_error){
		
		die("Sikertelen kapcsolódás!".$conn->connect_error);
		
	}


?>