<?php

	require "config.php";
	
	session_start();
	
	if(isset($_POST('login-btn'))){
		
		$username = $_POST['username'];
		
		$password = $_POST['password'];
		
		header["Location: index.php"];
		
	}
	
	echo <h1>Üdv, $_SESSION['username']</h1>

	if(isset($_POST('login-btn'))){
		
		$conn->query('SELECT * FROM users [id, $username, $password]');
		
	}
		else{
		
			echo "Helytelen jelszó";
		
	}
	else{
		
		echo "Már van ilyen felhasználó!";
		
	}


?>

<form method type="post">

	<input type="text" name="username" placeholder="username">
	
	<br><br>
	
	<input type="text" name="password" placeholder="password">
	
	<br><br>

	<input type="submit" name="log-btn" value="Bejelentkezés">

</form>

<a>Még nem regisztráltál? Regisztrálj itt!</a><a href="reg.php"></a>